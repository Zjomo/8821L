// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__6A27B01A_4A45_4A03_8B00_C34CBF6D2429__INCLUDED_)
#define AFX_STDAFX_H__6A27B01A_4A45_4A03_8B00_C34CBF6D2429__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include <stdio.h>

// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__6A27B01A_4A45_4A03_8B00_C34CBF6D2429__INCLUDED_)

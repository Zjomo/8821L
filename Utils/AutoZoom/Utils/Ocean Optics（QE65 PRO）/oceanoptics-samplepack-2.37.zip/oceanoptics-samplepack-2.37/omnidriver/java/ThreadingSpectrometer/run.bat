java -cp "build/classes;c:\Program Files\OceanOptics\OmniDriver\OOI_HOME\OmniDriver.jar" com.oceanoptics.threadingsample.ThreadedSpectrometerTest
